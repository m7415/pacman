var searchData=
[
  ['drawlives_237',['drawLives',['../classRenderer.html#a89e265e580d083f9f1f58777f4cd4a1e',1,'Renderer']]],
  ['drawscore_238',['drawScore',['../classRenderer.html#af1629566d938eaa883adfa02aa121673',1,'Renderer']]]
];
