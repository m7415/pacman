#include "GameController.h"
#include "constants.h"
#include <iostream>

int main() {
    GameController game;

    game.run();

    return 0;
}