var searchData=
[
  ['scatter_380',['SCATTER',['../constants_8h.html#a2811f6c090b957083ccbb709a01e60b0',1,'constants.h']]],
  ['screen_5fheight_381',['SCREEN_HEIGHT',['../constants_8h.html#a6974d08a74da681b3957b2fead2608b8',1,'constants.h']]],
  ['screen_5fwidth_382',['SCREEN_WIDTH',['../constants_8h.html#a2cd109632a6dcccaa80b43561b1ab700',1,'constants.h']]],
  ['starting_383',['STARTING',['../constants_8h.html#a0a662770058f59d1cccc737c9c52b446',1,'constants.h']]],
  ['stop_384',['STOP',['../constants_8h.html#ae19b6bb2940d2fbe0a79852b070eeafd',1,'constants.h']]]
];
