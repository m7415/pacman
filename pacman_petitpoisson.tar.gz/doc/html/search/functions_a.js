var searchData=
[
  ['oppositedirection_276',['oppositeDirection',['../classGhosts.html#ac68c9e83700a82ee8ebaa4f8aaa2f25c',1,'Ghosts']]]
];
