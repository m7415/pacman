var searchData=
[
  ['fps_28',['FPS',['../constants_8h.html#ac92ca5ab87034a348decad7ee8d4bd1b',1,'constants.h']]],
  ['frame_29',['frame',['../classRenderer.html#a0a10acb86a10156c2aa2dc8fa5fdbac8',1,'Renderer']]],
  ['frightened_30',['FRIGHTENED',['../constants_8h.html#a4bc3f9e3107aafe4e162e374cc185b1f',1,'constants.h']]],
  ['fruit_31',['FRUIT',['../constants_8h.html#a107e506d3278d51cd26e6e7d7fb951bc',1,'constants.h']]]
];
