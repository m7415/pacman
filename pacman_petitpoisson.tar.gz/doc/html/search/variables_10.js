var searchData=
[
  ['width_358',['width',['../classMaze.html#a773062dafae19d78f0d8b47846ea4286',1,'Maze']]],
  ['window_359',['window',['../classRenderer.html#a6cb53f6046afd78eafad503d16b0c07b',1,'Renderer']]]
];
