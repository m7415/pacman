var searchData=
[
  ['bg_307',['BG',['../constants_8h.html#aac263382f8d0384d676751ffc2d24afd',1,'constants.h']]]
];
