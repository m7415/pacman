var searchData=
[
  ['update_293',['update',['../classGame.html#a442a4960b4716fd25e7efd1e01be974e',1,'Game']]],
  ['updatescreen_294',['updateScreen',['../classRenderer.html#a3a515f7ae40af4bd2062a1e554c9d18f',1,'Renderer']]]
];
