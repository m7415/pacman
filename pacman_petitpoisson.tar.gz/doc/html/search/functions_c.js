var searchData=
[
  ['render_280',['render',['../classEntity.html#a6f2db49ab57bbc7a04f000b2d2ebcda4',1,'Entity::render()'],['../classGhosts.html#acf074084f4370c079e8a8ada0f0bc353',1,'Ghosts::render()'],['../classGomme.html#a2643ea20a1ff1b1184b5661b1bb04846',1,'Gomme::render()'],['../classPacman.html#a124c9b05d5cf830ff2d9ff26fdb87f93',1,'Pacman::render()'],['../classRenderer.html#aefe6c9be3bbb7261623fd45bf9316ab6',1,'Renderer::render(const Maze &amp;maze, std::shared_ptr&lt; Pacman &gt; pacman, std::vector&lt; std::shared_ptr&lt; Ghosts &gt;&gt; ghosts, int score, int state, int lives)']]],
  ['renderer_281',['Renderer',['../classRenderer.html#a7ebf46f54dab9905f79b80f7fddb76a6',1,'Renderer']]],
  ['reset_282',['reset',['../classGame.html#af88d351142dec622156f1348c918236d',1,'Game']]],
  ['run_283',['run',['../classGameController.html#a5d6169c7a3aae6db94690e2f27d780a2',1,'GameController']]]
];
