var searchData=
[
  ['handleghosts_265',['handleGhosts',['../classGame.html#a91999ea50e301541f09dc15ed0a3503a',1,'Game']]],
  ['handlepacgums_266',['handlePacgums',['../classGame.html#a3aa8a587bc01b021874667ba9b2080e9',1,'Game']]]
];
