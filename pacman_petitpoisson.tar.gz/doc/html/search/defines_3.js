var searchData=
[
  ['fps_370',['FPS',['../constants_8h.html#ac92ca5ab87034a348decad7ee8d4bd1b',1,'constants.h']]],
  ['frightened_371',['FRIGHTENED',['../constants_8h.html#a4bc3f9e3107aafe4e162e374cc185b1f',1,'constants.h']]],
  ['fruit_372',['FRUIT',['../constants_8h.html#a107e506d3278d51cd26e6e7d7fb951bc',1,'constants.h']]]
];
