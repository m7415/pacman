var searchData=
[
  ['scattertarget_343',['scatterTarget',['../classClyde.html#ab92ce21eeff62bb0e5f97d218e821e28',1,'Clyde::scatterTarget()'],['../classGhosts.html#a3c55084c81d3cc34f965a8ecfe3ce13f',1,'Ghosts::scatterTarget()'],['../classInky.html#aefb1f328deb85ef93108a7a62bbc8327',1,'Inky::scatterTarget()'],['../classPinky.html#ae79fbdf61f0afbfdf86ec4c05c83d44b',1,'Pinky::scatterTarget()'],['../classBlinky.html#a6dfd17f3f6187c69e1bb1f39f5e61d2e',1,'Blinky::scatterTarget()']]],
  ['score_344',['score',['../classGame.html#afaf9404196df9968103d5b0d0ad08139',1,'Game']]],
  ['screenheight_345',['screenHeight',['../classRenderer.html#abbec8ff9ba100cc41b697dd3a5a9af9f',1,'Renderer']]],
  ['screenwidth_346',['screenWidth',['../classRenderer.html#aec5ec57541b6c3f9d9817375ef256f5f',1,'Renderer']]],
  ['speed_347',['speed',['../classEntity.html#a1de3d8d9ab8088f61e6726069b26fa60',1,'Entity']]],
  ['sprite_348',['sprite',['../classGomme.html#a1ebf9456f0830cbb7cf110abed4f81d5',1,'Gomme']]],
  ['sprites_349',['sprites',['../classEntity.html#a73167471f72662bb137a378cc0657384',1,'Entity::sprites()'],['../classGhosts.html#a9a7a94493a862c879f4d0458435f970d',1,'Ghosts::sprites()'],['../classPacman.html#a6f8c1ff4c368d67555d742989fca6fea',1,'Pacman::sprites()']]],
  ['src_5fbg_350',['SRC_BG',['../constants_8h.html#acb6a1b30ad00589fae244d33e358f26d',1,'constants.h']]],
  ['src_5fgum_351',['SRC_GUM',['../constants_8h.html#a0934e55f807a7a255d9a14e209491e4e',1,'constants.h']]],
  ['src_5fpacgum_352',['SRC_PACGUM',['../constants_8h.html#a4d2fed79413bcf041db152bcc3735ecb',1,'constants.h']]],
  ['state_353',['state',['../classGameController.html#a488d3c3da8196d552226c800f6e2724f',1,'GameController']]],
  ['surface_5fbmp_354',['surface_bmp',['../classRenderer.html#a72f4f112af2fb70afebed6fc909963ae',1,'Renderer']]]
];
